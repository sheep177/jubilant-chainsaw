package com.example.assesment1;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.assesment1.provider.Categories;
import com.example.assesment1.provider.CategoriesViewModel;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.ArrayList;

public class FragmentListCategory extends Fragment {

    private RecyclerView recyclerView;
    private MyRecyclerAdapter recyclerAdapter;
    private ArrayList<Categories> fragmentListCategories;

    private CategoriesViewModel categoriesViewModel;

    public FragmentListCategory() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_list_category, container, false);

        recyclerView = view.findViewById(R.id.fragment_CategoriesrecyclerView);
        // Set the layout manager
        recyclerView.setLayoutManager(new LinearLayoutManager(view.getContext()));
        // Initialize the ArrayList
        fragmentListCategories = new ArrayList<>();

        categoriesViewModel = new ViewModelProvider(this).get(CategoriesViewModel.class);

        // Initialize the adapter with the data
        recyclerAdapter = new MyRecyclerAdapter();
        recyclerAdapter.setData(fragmentListCategories);

        // Set the adapter to the RecyclerView
        recyclerView.setAdapter(recyclerAdapter);
        // Load data into the ArrayList
        loadCategories();

        return view;
    }
    public void loadCategories (){
        categoriesViewModel.getAllCategories().observe(getViewLifecycleOwner(), newData -> {
            // cast List<Student> to ArrayList<Student>
            recyclerAdapter.setData(new ArrayList<Categories>(newData));  //this part is to notify change in Database to recyclerView
            recyclerAdapter.notifyDataSetChanged();
        });
    }

}


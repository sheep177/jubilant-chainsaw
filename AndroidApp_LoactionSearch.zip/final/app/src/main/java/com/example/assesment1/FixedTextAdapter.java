package com.example.assesment1;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class FixedTextAdapter extends RecyclerView.Adapter<FixedTextAdapter.FixedTextViewHolder> {

    @NonNull
    @Override
    public FixedTextViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.headerl_ayout, parent, false);
        return new FixedTextViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FixedTextViewHolder holder, int position) {

    }

    @Override
    public int getItemCount() {

        return 1;
    }

    static class FixedTextViewHolder extends RecyclerView.ViewHolder {
        public FixedTextViewHolder(View itemView) {
            super(itemView);

        }
    }
}


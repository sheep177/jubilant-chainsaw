package com.example.assesment1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.RecyclerView;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Random;
import java.util.StringTokenizer;

import com.example.assesment1.provider.Categories;
import com.example.assesment1.provider.CategoriesViewModel;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class newEventCategory extends AppCompatActivity {
    SharedPreferences sharedPreferences;
    Switch switchIsActive;

    EditText etCategoryName;
    EditText etEventCount;
    TextView etCategoryId;

    EditText etLocation;

    ArrayAdapter<String> adapter;
    RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;
    MyRecyclerAdapter recyclerAdapter;

    // to hold the reference to ListView UI element
    ArrayList<Categories> listCategories;

    private SMSReceiver smsReceiver;

    Gson gson = new Gson();

    private CategoriesViewModel categoriesViewModel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_new_event_category);



        etCategoryName = findViewById(R.id.editTextName);
        etCategoryId = findViewById(R.id.editTextId);
        switchIsActive = findViewById(R.id.switchIsActive);
        etEventCount = findViewById(R.id.editTextEventCount);
        etLocation = findViewById(R.id.editTextLocation);


        ActivityCompat.requestPermissions(this, new String[]{
                android.Manifest.permission.SEND_SMS,
                android.Manifest.permission.RECEIVE_SMS,
                android.Manifest.permission.READ_SMS
        }, 0);

        smsReceiver = new SMSReceiver();
        registerReceiver(smsReceiver, new IntentFilter("android.provider.Telephony.SMS_RECEIVED"));

        MyBroadCastReceiver myBroadCastReceiver = new MyBroadCastReceiver();

        registerReceiver(myBroadCastReceiver, new IntentFilter(SMSReceiver.SMS_FILTER), RECEIVER_EXPORTED);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        recyclerAdapter = new MyRecyclerAdapter();


        categoriesViewModel = new ViewModelProvider(this).get(CategoriesViewModel.class);
        // subscribe to LiveData of type ArrayList<Student>,
        // any changes detected in the database will be notified to MainActivity
        categoriesViewModel.getAllCategories().observe(this, newData -> {
            // cast List<Student> to ArrayList<Student>
            recyclerAdapter.setData(new ArrayList<Categories>(newData));  //this part is to notify change in Database to recyclerView
            recyclerAdapter.notifyDataSetChanged();
        });

    }

    public void onSaveButtonClick(View view) {
        String categoryName = etCategoryName.getText().toString();
       int intEventCount = Integer.parseInt(etEventCount.getText().toString());
       int eventCount = intEventCount;
        boolean isActive = switchIsActive.isChecked();
        String newCategoryId = generateCategoryId();
        String strLocation = etLocation.getText().toString();

        if(isValidCategoryName(categoryName)){
            if(intEventCount >= 0){
                etCategoryId.setText(newCategoryId);
                Categories category = new Categories(newCategoryId, categoryName, eventCount, isActive,strLocation);

                categoriesViewModel.insert(category);

                Intent intent = new Intent(newEventCategory.this,DashBoardActivity.class);
                startActivity(intent);
            }else{
                etCategoryId.setText(newCategoryId);
                Toast.makeText(this, "invalid Event Count", Toast.LENGTH_LONG).show();
                eventCount = 0;
                Categories category = new Categories(newCategoryId, categoryName, eventCount, isActive,strLocation);

                categoriesViewModel.insert(category);

                Intent intent = new Intent(newEventCategory.this,DashBoardActivity.class);
                startActivity(intent);
            }
            }else{
                Toast.makeText(this, "invalid Category Name", Toast.LENGTH_LONG).show();
            }
    }


    public String generateCategoryId() {
        Random random = new Random();

        // Generate two random uppercase letters
        char letter1 = (char) ('A' + random.nextInt(26));
        char letter2 = (char) ('A' + random.nextInt(26));

        // Generate four random digits
        int digits = random.nextInt(10000);

        // Format the category ID
        return String.format("C%c%c-%04d", letter1, letter2, digits);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.back_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.nav_back) {
            Intent intent = new Intent(newEventCategory.this,DashBoardActivity.class);
            startActivity(intent);
        }
        return true;
    }


private boolean isValidCategoryName(String category) {
    boolean hasValidChars = category.matches("[a-zA-Z]+[a-zA-Z0-9 ]*");
    return hasValidChars;
}


    class MyBroadCastReceiver extends BroadcastReceiver {
        /*
         * This method 'onReceive' will get executed every time class SMSReceive sends a broadcast
         * */
        @Override
        public void onReceive(Context context, Intent intent) {
            // Tokenize received message here

            /*
             * Retrieve the message from the intent
             * */
            String msg = intent.getStringExtra(SMSReceiver.SMS_MSG_KEY);
            myStringTokenizer(msg);
        }

        public void myStringTokenizer(String msg) {
            /*
             * String Tokenizer is used to parse the incoming message
             * The protocol is to have the account holder name and account number separate by a semicolon
             * */
            if (msg.startsWith("category:")) {
                //delete it and go to next check step
                msg = msg.substring("category:".length());
                StringTokenizer sT = new StringTokenizer(msg, ";");
                //only 3 element can be checked
                if (sT.countTokens() == 3) {
                    String categoryName = sT.nextToken();
                    String eventCount = sT.nextToken();
                    String IsActive = sT.nextToken();
                    //check if number follow the rules
                    if (isInteger(eventCount) && checkPositiveNum(eventCount) && isBooleanCheck(IsActive)) {
                        etCategoryName.setText(categoryName);
                        etEventCount.setText(String.valueOf(eventCount));
                        //after check its boolean value , then concert to show
                        boolean IsActiveBool = Boolean.parseBoolean(IsActive);
                        switchIsActive.setChecked(IsActiveBool);
                    } else {
                        Toast.makeText(newEventCategory.this, "missing parameters or invalid values", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(newEventCategory.this, "missing parameters or invalid values", Toast.LENGTH_SHORT).show();
                }

            }else{
                Toast.makeText(newEventCategory.this, "missing parameters or invalid values", Toast.LENGTH_SHORT).show();
            }

        }

        public boolean isInteger(String value) {
            try {
                Integer.parseInt(value);
                return true;
            } catch (NumberFormatException e) {
                return false;
            }
        }

        public boolean checkPositiveNum(String eventCountString) {
            try {
                int eventCount = Integer.parseInt(eventCountString);
                if (eventCount >= 0) {
                    return true;
                } else {
                    return false;
                }
            } catch (NumberFormatException e) {
                return false;
            }
        }

        public boolean isBooleanCheck(String value) {
            try {

                if ("true".equalsIgnoreCase(value) || "false".equalsIgnoreCase(value)) {
                    return true;
                } else {
                    return false;
                }
            } catch (Exception e) {
                return false;
            }
        }

    }
}


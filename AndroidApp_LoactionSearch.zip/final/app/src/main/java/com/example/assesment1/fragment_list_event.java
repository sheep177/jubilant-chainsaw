package com.example.assesment1;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.assesment1.provider.Categories;
import com.example.assesment1.provider.CategoriesViewModel;
import com.example.assesment1.provider.Events;
import com.example.assesment1.provider.EventsViewModel;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class fragment_list_event extends Fragment {
    private RecyclerView fragment_EventsRecyclerView;
    private EventsAdapter eventsAdapter;
    private ArrayList<Events> fragmentListEvents;
    private ArrayList<Categories> fragmentListCategories;
    private EventsViewModel eventsViewModel;
    private CategoriesViewModel categoriesViewModel;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_list_event, container, false);

        fragment_EventsRecyclerView = view.findViewById(R.id.fragment_EventsRecyclerView);
        // Set the layout manager
        fragment_EventsRecyclerView.setLayoutManager(new LinearLayoutManager(view.getContext()));
        // Initialize the ArrayList
        fragmentListEvents = new ArrayList<>();

        eventsViewModel = new ViewModelProvider(this).get(EventsViewModel.class);

        // Initialize the adapter with the data
        eventsAdapter = new EventsAdapter();
        eventsAdapter.setData(fragmentListEvents);

        // Set the adapter to the RecyclerView
        fragment_EventsRecyclerView.setAdapter(eventsAdapter);
        // Load data into the ArrayList
        loadCategories();

        return view;
    }

    public void loadCategories (){
        eventsViewModel.getAllEvents().observe(getViewLifecycleOwner(), newData -> {
            // cast List<Student> to ArrayList<Student>
            eventsAdapter.setData(new ArrayList<Events>(newData));  //this part is to notify change in Database to recyclerView
            eventsAdapter.notifyDataSetChanged();
        });

    }
}
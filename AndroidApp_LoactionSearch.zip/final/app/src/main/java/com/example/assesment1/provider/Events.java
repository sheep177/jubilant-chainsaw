package com.example.assesment1.provider;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;
@Entity(tableName = "Events")
public class Events {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    private int Database_id;
    @ColumnInfo(name = "Event_name")
    private String eventName;
    @ColumnInfo(name = "Event_id")
    private String eventId;
    @ColumnInfo(name = "Event_Available")
    private int eventAvailable;
    @ColumnInfo(name = "Event_isActive")
    private boolean eventIsActive;
    @ColumnInfo(name = "Category_id")
    private String categoryId;

    public Events(String eventName, String eventId, int eventAvailable, boolean eventIsActive, String categoryId) {
        this.eventName = eventName;
        this.eventId = eventId;
        this.eventAvailable = eventAvailable;
        this.eventIsActive = eventIsActive;
        this.categoryId = categoryId;

    }

    public String getEventName() {
        return eventName;
    }

    public String getEventId() {
        return eventId;
    }

    public int getEventAvailable() {
        return eventAvailable;
    }

    public boolean isEventIsActive() {
        return eventIsActive;
    }
    public String getCategoryId() {
        return categoryId;
    }

    public int getDatabase_id() {
        return Database_id;
    }

    public void setDatabase_id(int database_id) {
        Database_id = database_id;
    }


}

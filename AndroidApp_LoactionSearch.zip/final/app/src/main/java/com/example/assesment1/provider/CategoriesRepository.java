package com.example.assesment1.provider;

import android.app.Application;

import androidx.lifecycle.LiveData;

import java.util.List;

public class CategoriesRepository {
    // private class variable to hold reference to DAO
    private CategoriesDAO categoriesDAO;
    // private class variable to temporary hold all the items retrieved and pass outside of this class
    private LiveData<List<Categories>> allCategoriesLiveData;

    CategoriesRepository(Application application){
        // get reference/instance of the database
        EMADatabase_V19 db = EMADatabase_V19.getDatabase(application);

        // get reference to DAO, to perform CRUD operations
        categoriesDAO = db.categoriesDAO();

        // once the class is initialised get all the items in the form of LiveData
        allCategoriesLiveData = categoriesDAO.getAllCategories();
    }

    /**
     * Repository method to get all cards
     * @return LiveData of type List<Item>
     */
    LiveData<List<Categories>> getAllCategories() {
        return allCategoriesLiveData;
    }

    /**
     * Repository method to insert one single item
     * @param categories object containing details of new Item to be inserted
     */
    void insert(Categories categories) {
        EMADatabase_V19.databaseWriteExecutor.execute(() -> categoriesDAO.addCategories(categories));
    }

    /**
     * Repository method to delete all records
     */
    void deleteAll() {
        EMADatabase_V19.databaseWriteExecutor.execute(() -> categoriesDAO.deleteAllCategories());
    }



    public LiveData<Categories> getCategoryById(String categoryId) {
        return categoriesDAO.getCategoryById(categoryId);
    }


    void updateCategory(Categories categories) {
        EMADatabase_V19.databaseWriteExecutor.execute(() -> categoriesDAO.updateCategory(categories));
    }

}

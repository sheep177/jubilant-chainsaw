package com.example.assesment1.provider;


import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;

import java.util.List;

/**
 * ViewModel class is used for pre-processing the data,
 * before passing it to the controllers (Activity or Fragments). ViewModel class should not hold
 * direct reference to database. ViewModel class relies on repository class, hence the database is
 * accessed using the Repository class.
 */
public class EventsViewModel extends AndroidViewModel{
    // reference to StudentRepository
    private EventsRepository repository;
    // private class variable to temporary hold all the items retrieved and pass outside of this class
    private LiveData<List<Events>> allEventsLiveData;

    public EventsViewModel(@NonNull Application application) {
        super(application);

        // get reference to the repository class
        repository = new EventsRepository(application);

        // get all items by calling method defined in repository class
        allEventsLiveData = repository.getAllEvents();
    }

    /**
     * ViewModel method to get all students
     * @return LiveData of type List<Student>
     */
    public LiveData<List<Events>> getAllEvents() {
        return allEventsLiveData;
    }


    /**
     * ViewModel method to insert one single item
     * @param events object containing details of new Item to be inserted
     */
    public void insert(Events events) {
        repository.insert(events);
    }

    /**
     * ViewModel method to delete all records
     */
    public void deleteAll() {
        repository.deleteAll();
    }

    public void delete(Events eventToDelete){
        repository.delete(eventToDelete);
    }


}

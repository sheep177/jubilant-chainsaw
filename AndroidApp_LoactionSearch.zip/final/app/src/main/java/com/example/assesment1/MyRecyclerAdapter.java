package com.example.assesment1;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.assesment1.provider.Categories;

import java.util.ArrayList;

public class MyRecyclerAdapter extends RecyclerView.Adapter<MyRecyclerAdapter.CustomViewHolder> {

    ArrayList<Categories> data = new ArrayList<Categories>();
    public void setData(ArrayList<Categories> data) {
        this.data = data;
    }

    @NonNull
    @Override
    public CustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.categories_card_layout, parent, false);
        CustomViewHolder viewHolder = new CustomViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull CustomViewHolder holder, int position) {
        Categories categories = data.get(position);
        holder.tvCategoryName.setText(categories.getName());
        holder.tvCategoryId.setText(categories.getId());
        holder.tvCount.setText(String.valueOf(categories.getEventCount()));
        holder.tvIsActive.setText(categories.isActive() ? "Active" : "Inactive");

        holder.categories_card_layout.setOnClickListener(v -> {
            String selectedStudentCountry = data.get(position).getLocation();

            // TODO: Launch new MapsActivity with Country Name in extras
            // TODO: Launch new MapsActivity with Country Name in extras
            Context context = holder. categories_card_layout.getContext();
            Intent intent = new Intent (context, GoogleMapActivity.class);
            intent.putExtra("studentCountry", selectedStudentCountry);
            context.startActivity (intent) ;

        });

    }

    @Override
    public int getItemCount() {
        if (this.data != null) {
            return this.data.size();
        }
        return 0;
    }

    public class CustomViewHolder extends RecyclerView.ViewHolder{
        public TextView tvCategoryName;
        public TextView tvCategoryId;
        public TextView tvCount;
        public TextView tvIsActive;

        public View categories_card_layout;

        public CustomViewHolder(@NonNull View itemView) {
            super(itemView);
            categories_card_layout = itemView;
            tvCategoryId = itemView.findViewById(R.id.tv_id);
            tvCategoryName = itemView.findViewById(R.id.tv_name);
            tvIsActive = itemView.findViewById(R.id.tv_active);
            tvCount = itemView.findViewById(R.id.tv_eventCount);
        }


    }

}
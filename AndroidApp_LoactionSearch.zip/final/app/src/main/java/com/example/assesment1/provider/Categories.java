package com.example.assesment1.provider;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "Categories")
public class Categories {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    private int Database_id;
    @ColumnInfo(name = "Category_id")
    private String id;
    @ColumnInfo(name = "Category_name")
    private String name;
    @ColumnInfo(name = "Category_eventCount")
    private int eventCount;
    @ColumnInfo(name = "Category_isActive")
    private boolean isActive;
    @ColumnInfo(name = "Category_location")
    private String Location;


    public Categories(String id, String name, int eventCount, boolean isActive,String Location) {
        this.id = id;
        this.name = name;
        this.eventCount = eventCount;
        this.isActive = isActive;
        this.Location = Location;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getEventCount() {
        return eventCount;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setEventCount(int eventCount) {
        this.eventCount = eventCount;
    }

    public int getDatabase_id() {
        return Database_id;
    }

    public void setDatabase_id(int database_id) {
        Database_id = database_id;
    }

    public String getLocation() {
        return Location;
    }

    public void setLocation(String location) {
        Location = location;
    }
}

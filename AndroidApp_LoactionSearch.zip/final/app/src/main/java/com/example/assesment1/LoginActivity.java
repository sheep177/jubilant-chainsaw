package com.example.assesment1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    }





    public void onLoginClick(View v) {


        SharedPreferences sharedPreferences = getSharedPreferences("userInfo", MODE_PRIVATE);

        EditText editTextUsernameLogin = findViewById(R.id.usernameLogin);
        EditText editTextPasswordLogin = findViewById(R.id.passwordLogin);

        String username = editTextUsernameLogin.getText().toString();
        String password = editTextPasswordLogin.getText().toString();
        String correctUsername = sharedPreferences.getString("username", "defaultUsername");
        String correctPassword = sharedPreferences.getString("password", "defaultUsername");
        //if enter same as saved data, then login successful
        if (username.equals(correctUsername) && password.equals(correctPassword)) {

            Intent intent = new Intent(LoginActivity.this, DashBoardActivity.class);
            startActivity(intent);
        } else {

            Toast.makeText(LoginActivity.this, "Authentication failure: Username or Password incorrect", Toast.LENGTH_LONG).show();
        }
    }

}


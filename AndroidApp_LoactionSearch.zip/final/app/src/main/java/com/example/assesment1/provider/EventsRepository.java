package com.example.assesment1.provider;

import android.app.Application;

import androidx.lifecycle.LiveData;

import java.util.List;

public class EventsRepository {

    // private class variable to hold reference to DAO
    private EventsDAO eventsDAO;
    // private class variable to temporary hold all the items retrieved and pass outside of this class
    private LiveData<List<Events>> allEventsLiveData;

    EventsRepository(Application application){
        // get reference/instance of the database
        EMADatabase_V19 db = EMADatabase_V19.getDatabase(application);

        // get reference to DAO, to perform CRUD operations
        eventsDAO = db.eventsDAO();

        // once the class is initialised get all the items in the form of LiveData
        allEventsLiveData = eventsDAO.getAllEvents();
    }

    /**
     * Repository method to get all cards
     * @return LiveData of type List<Item>
     */
    LiveData<List<Events>> getAllEvents() {
        return allEventsLiveData;
    }

    /**
     * Repository method to insert one single item
     * @param events object containing details of new Item to be inserted
     */
    void insert(Events events) {
        EMADatabase_V19.databaseWriteExecutor.execute(() -> eventsDAO.addEvents(events));
    }

    /**
     * Repository method to delete all records
     */
    void deleteAll() {
        EMADatabase_V19.databaseWriteExecutor.execute(() -> eventsDAO.deleteAllEvents());
    }

    void delete(Events eventsToDelete){
        EMADatabase_V19.databaseWriteExecutor.execute(() -> eventsDAO.delete(eventsToDelete));
    }




}

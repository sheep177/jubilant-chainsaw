package com.example.assesment1.provider;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;
@Dao
public interface EventsDAO {
    @Query("select * from Events")
    LiveData<List<Events>> getAllEvents();

    @Insert
    void addEvents(Events events);

    @Query("DELETE FROM Events")
    void deleteAllEvents();

    // delete one
    @Delete
    void delete(Events eventsToDelete);

}

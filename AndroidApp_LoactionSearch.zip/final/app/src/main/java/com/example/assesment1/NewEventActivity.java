package com.example.assesment1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;
import java.util.StringTokenizer;

public class NewEventActivity extends AppCompatActivity {
    SharedPreferences sharedPreferences;
    Switch switchIsActive;

    EditText etCategoryName;
    EditText etCategoryId;
    EditText etTicktsAvailable;
    EditText etEventName;
    TextView etEventId;

    private SMSReceiver smsReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_event);

        // get reference to the UI elements
        // findViewById method looks for elements by the Id we set on elements
        // and search for them on current Activity's UI
        etEventName = findViewById(R.id.editTextEventName);
        etEventId = findViewById(R.id.editTextEventId);
        etCategoryId = findViewById(R.id.editTextCategoryId);
        etTicktsAvailable = findViewById(R.id.editTextTicketsAvailable);
        switchIsActive = findViewById(R.id.newSwitchIsActive);







        ActivityCompat.requestPermissions(this, new String[]{
                android.Manifest.permission.SEND_SMS,
                android.Manifest.permission.RECEIVE_SMS,
                android.Manifest.permission.READ_SMS
        }, 0);

        //we need to inform Android OS, that our application is requesting permission to read/receive incoming messages.
        SMSReceiver smsReceiver = new SMSReceiver();
        registerReceiver(smsReceiver, new IntentFilter("android.provider.Telephony.SMS_RECEIVED"));
        //MyBroadCastReceiver myBroadCastReceiver = new MyBroadCastReceiver(); 创建了MyBroadCastReceiver的一个实例。这是另一个继承自BroadcastReceiver的类，用于处理自定义广播。
        MyBroadCastReceiver myBroadCastReceiver = new MyBroadCastReceiver();

         //Register the broadcast handler with the intent filter that is declared in
         // class SMSReceiver
        registerReceiver(myBroadCastReceiver, new IntentFilter(SMSReceiver.SMS_FILTER), RECEIVER_EXPORTED);
    }


    public void onSaveEventClick(View view){

        etEventName = findViewById(R.id.editTextEventName);
        etEventId = findViewById(R.id.editTextEventId);
        etCategoryId = findViewById(R.id.editTextCategoryId);
        etTicktsAvailable = findViewById(R.id.editTextTicketsAvailable);
        switchIsActive = findViewById(R.id.newSwitchIsActive);

        // using the referenced UI elements we extract values into plain text format
        String EventName = etEventName.getText().toString();
        String CategoryId = etCategoryId.getText().toString();
        String ticketsAvailable = etTicktsAvailable.getText().toString();
        int intTicketsAvailable = Integer.parseInt(ticketsAvailable);
        boolean isActive = switchIsActive.isChecked();

        //no need to getText from category ID
        String newEventId = generateEventId(); // generate CategoryId
        etEventId.setText(newEventId);

        saveFruitDetailsToPreference(EventName, CategoryId, ticketsAvailable, intTicketsAvailable, isActive);
        Toast.makeText(this,"Event saved: " + newEventId + " to " + CategoryId , Toast.LENGTH_LONG).show();
    }



    public String generateEventId() {
        Random random = new Random();

        // Generate two random uppercase letters
        char letter1 = (char) ('A' + random.nextInt(26));
        char letter2 = (char) ('A' + random.nextInt(26));

        // Generate four random digits
        int digits = random.nextInt(100000);

        // Format the category ID
        return String.format("E%c%c-%05d", letter1, letter2, digits);
    }





    private void saveFruitDetailsToPreference(String eventName, String eventId, String CategoryId, int TicketsAvailable, boolean SwitchIsActive) {

        SharedPreferences sharedPreferences = getSharedPreferences("EventInfo", MODE_PRIVATE);

        // use .edit function to access file using Editor variable
        SharedPreferences.Editor editor = sharedPreferences.edit();

        // save key-value pairs to the shared preference file

        editor.putString("EventName", eventName);
        editor.putString("EventId", eventId);
        editor.putString("CategoryId", CategoryId);
        editor.putInt("Tickets", TicketsAvailable);
        editor.putBoolean("IsActive", SwitchIsActive);



        // use editor.apply() to save data to the file asynchronously (in background without freezing the UI)
        // doing in background is very common practice for any File Input/Output operations
        editor.apply();
    }

    class MyBroadCastReceiver extends BroadcastReceiver {
        /*
         * This method 'onReceive' will get executed every time class SMSReceive sends a broadcast
         * */
        @Override
        public void onReceive(Context context, Intent intent) {

            String msg = intent.getStringExtra(SMSReceiver.SMS_MSG_KEY);

            myStringTokenizer(msg);
        }
        public void myStringTokenizer(String msg){
            /*
             * String Tokenizer is used to parse the incoming message
             * The protocol is to have the account holder name and account number separate by a semicolon
             * */
            if (msg.startsWith("event:")) {
                //delete it and go to next check
                msg = msg.substring("event:".length());
                StringTokenizer sT = new StringTokenizer(msg, ";");
                //only 4 element can be checked
                if(sT.countTokens() == 4) {

                    String EventName = sT.nextToken();
                    String CategoryId = sT.nextToken();
                    String ticketsAvailable = sT.nextToken();
                    String isActive = sT.nextToken();
                    //check if integer follow the rules
                    if(isInteger(ticketsAvailable) && checkPositiveNum(ticketsAvailable) && isBooleanCheck(isActive)) {
                        etEventName.setText(EventName);
                        etCategoryId.setText((CategoryId));
                        etTicktsAvailable.setText(String.valueOf(ticketsAvailable));
                        //after check its boolean value , then concert to show
                        boolean isActiveBool = Boolean.parseBoolean(isActive);
                        switchIsActive.setChecked(isActiveBool);
                    } else {
                        Toast.makeText(NewEventActivity.this, "missing parameters or invalid values", Toast.LENGTH_SHORT).show();
                    }
                }
                else{
                    Toast.makeText(NewEventActivity.this, "missing parameters or invalid values", Toast.LENGTH_SHORT).show();
                }
                }else {
                    Toast.makeText(NewEventActivity.this, "missing parameters or invalid values", Toast.LENGTH_SHORT).show();
                }

        }

        public boolean isInteger(String value) {
            try {
                Integer.parseInt(value);
                return true;
            } catch (NumberFormatException e) {
                return false;
            }
        }

        public boolean checkPositiveNum(String eventCountString) {
            try {
                int eventCount = Integer.parseInt(eventCountString);
                if (eventCount >= 0) {
                    return true;
                } else {
                    return false;
                }
            } catch (NumberFormatException e) {
                return false;
            }
        }

        public boolean isBooleanCheck(String value) {
            try {


                if ("true".equalsIgnoreCase(value) || "false".equalsIgnoreCase(value)) {
                    return true;
                } else {
                    return false;
                }
            } catch (Exception e) {
                return false;
            }
        }


    }
}

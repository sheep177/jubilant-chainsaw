package com.example.assesment1;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.assesment1.provider.Categories;
import com.example.assesment1.provider.Events;
import com.example.assesment1.provider.EventsViewModel;

import java.util.ArrayList;

public class EventsAdapter extends RecyclerView.Adapter<EventsAdapter.CustomViewHolder> {
    ArrayList<Events> data = new ArrayList<Events>();

    public void setData(ArrayList<Events> data) {
        this.data = data;
    }


    @NonNull
    @Override
    public EventsAdapter.CustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.events_card_layout, parent, false);
        EventsAdapter.CustomViewHolder viewHolder = new EventsAdapter.CustomViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull EventsAdapter.CustomViewHolder holder, int position) {
        Events events = data.get(position);

        holder.tvEventName.setText(events.getEventName());
        holder.tvEventId.setText(events.getEventId());
        holder.tvEventCount.setText(String.valueOf(events.getEventAvailable()));
        holder.tvEventIsActive.setText(events.isEventIsActive() ? "Active" : "Inactive");
        holder.tvCategoryId.setText(events.getCategoryId());

        holder.events_card_layout.setOnClickListener(v -> {
            String selectedEvents = data.get(position).getEventId();

            // 获取当前视图的上下文（通常是Activity），用于启动新Activity这里是recyclerview
            Context context = holder. events_card_layout.getContext();
            Intent intent = new Intent (context, EventGoogleResult.class);
            intent.putExtra("selectedEvents", selectedEvents);
            context.startActivity (intent) ;

        });

    }

    @Override
    public int getItemCount() {
        if (this.data != null) {
            return this.data.size();
        }
        // else return zero if data is null
        return 0;
    }

    public class CustomViewHolder extends RecyclerView.ViewHolder{
        public TextView tvEventId;
        public TextView tvEventName;
        public TextView tvEventIsActive;
        public TextView tvEventCount;

        public TextView tvCategoryId;
        public View events_card_layout;




        public CustomViewHolder(@NonNull View itemView) {
            super(itemView);
            events_card_layout = itemView;
            tvEventId = itemView.findViewById(R.id.tv_id);
            tvEventName = itemView.findViewById(R.id.tv_name);
            tvEventIsActive = itemView.findViewById(R.id.tv_active);
            tvEventCount = itemView.findViewById(R.id.tv_eventCount);
            tvCategoryId = itemView.findViewById(R.id.tv_category_id);

        }


    }

}

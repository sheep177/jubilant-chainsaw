package com.example.assesment1.provider;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;
@Dao
public interface CategoriesDAO {
    @Query("select * from categories")
    LiveData<List<Categories>> getAllCategories();

    @Insert
    void addCategories(Categories categories);

    @Query("DELETE FROM Categories")
    void deleteAllCategories();



    @Query("SELECT * FROM Categories WHERE Category_id = :categoryId")
    LiveData<Categories> getCategoryById(String categoryId);


    @Update
    void updateCategory(Categories categories);



}
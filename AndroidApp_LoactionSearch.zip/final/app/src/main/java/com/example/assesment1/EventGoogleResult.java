package com.example.assesment1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class EventGoogleResult extends AppCompatActivity {

    private String selectedEvents;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_google_result);

        // using the ID set in previous step, get reference to the WebView
        WebView webView = findViewById(R.id.googleWebView);

// get country name from Intent
        selectedEvents = getIntent().getExtras().getString("selectedEvents",selectedEvents);


// compile the Wikipedia URL, which will be used to load into WebView
        String wikiPageURL = "https://www.google.com/search?q=" + selectedEvents;

// set new WebView Client for the WebView
// This gives the WebView ability to be load the URL in the current WebView
// instead of navigating to default web browser of the device
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl(wikiPageURL);

    }
}
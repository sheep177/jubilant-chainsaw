package com.example.assesment1;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GestureDetectorCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.GestureDetector;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.example.assesment1.provider.Categories;
import com.example.assesment1.provider.CategoriesViewModel;
import com.example.assesment1.provider.Events;
import com.example.assesment1.provider.EventsViewModel;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.atomic.AtomicBoolean;

public class DashBoardActivity extends AppCompatActivity {

    Toolbar toolbar;
    Switch switchIsActive;
    EditText  etCategoryId, etTicktsAvailable, etEventName;
    TextView etEventId;
    FloatingActionButton fab;


    private DrawerLayout drawerLayout;
    private NavigationView navigationView;

    public ActionBarDrawerToggle actionBarDrawerToggle;

    // 数据存储
    ArrayAdapter<String> adapter;
    RecyclerView recyclerView;
    RecyclerView CategoriesRecyclerView;
    RecyclerView.LayoutManager layoutManager;
    MyRecyclerAdapter recyclerAdapter;
    EventsAdapter eventsAdapter;
    RecyclerView headerRecyclerView;
    FixedTextAdapter headerAdapter;



    // to hold the reference to ListView UI element
    ArrayList<Categories> listCategories;
    ArrayList<Events> listEvents;

    FragmentManager fragmentManager;
    FragmentListCategory fragmentListCategory;

    fragment_list_event fragment_list_event;
    private CategoriesViewModel categoriesViewModel;
    private EventsViewModel eventsViewModel;


    RecyclerView HrecyclerView;

    // help detect basic gestures like scroll, single tap, double tap, etc
    private GestureDetectorCompat mDetector;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dash_board);


        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        switchIsActive = findViewById(R.id.db_IsActive);
        etEventId = findViewById(R.id.db_EventId);
        etEventName = findViewById(R.id.db_EventName);
        etCategoryId = findViewById(R.id.db_CategoryId);
        etTicktsAvailable = findViewById(R.id.db_TicketsAvailable);

        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);



        actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar,
                R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();


        eventsAdapter = new EventsAdapter();
        eventsViewModel = new ViewModelProvider(this).get(EventsViewModel.class);
        // subscribe to LiveData of type ArrayList<Student>,
        // any changes detected in the database will be notified to MainActivity
        eventsViewModel.getAllEvents().observe(this, newData -> {
            // cast List<Student> to ArrayList<Student>
            eventsAdapter.setData(new ArrayList<Events>(newData));  //this part is to notify change in Database to recyclerView
            eventsAdapter.notifyDataSetChanged();
        });


        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(view -> {
            String strEventId = generateEventId();
            String strEventName = etEventName.getText().toString();
            int intTicketsAvailable = Integer.parseInt(etTicktsAvailable.getText().toString());
            int TicketsAvailable;
            String strTicketsAvailable = etTicktsAvailable.getText().toString();
            boolean boolTicketsAvailable = etTicktsAvailable.isActivated();
            String strCategoryId = etCategoryId.getText().toString();



            if (isCategoryIdExists(strCategoryId)) {
                if (isValidEventName(strEventName)) {
                    if (intTicketsAvailable >= 0) {
                        TicketsAvailable = intTicketsAvailable;
                        Events events = new Events(strEventId, strEventName, TicketsAvailable, boolTicketsAvailable,strCategoryId);
                        etEventId.setText(strEventId);


                        updateCategoryEventCount(strCategoryId, TicketsAvailable);

                        eventsViewModel.insert(events);
                        Toast.makeText(this, "Event Successfully saved", Toast.LENGTH_LONG).show();

                        //show snackbar
                        Snackbar.make(findViewById(android.R.id.content), "Event Saved", Snackbar.LENGTH_LONG)
                                .setAction("UNDO", v -> undoLastSaveEventOperation(strCategoryId,TicketsAvailable))
                                .show();
                    } else {
                        Toast.makeText(this, "Invalid 'Tickets available", Toast.LENGTH_LONG).show();
                        TicketsAvailable = 0;
                        etEventId.setText(strEventId);

                        Events events = new Events(strEventId, strEventName, TicketsAvailable, boolTicketsAvailable,strCategoryId);

                        updateCategoryEventCount(strCategoryId, TicketsAvailable);
                        eventsViewModel.insert(events);

                        //show snackbar
                        Snackbar.make(findViewById(android.R.id.content), "Event Saved", Snackbar.LENGTH_LONG)
                                .setAction("UNDO", v -> undoLastSaveEventOperation(strCategoryId,TicketsAvailable))
                                .show();
                    }
                } else {
                    TicketsAvailable = intTicketsAvailable;
                    Toast.makeText(this, "invalid Event Name", Toast.LENGTH_LONG).show();
                }

            } else {
                TicketsAvailable = intTicketsAvailable;
                Toast.makeText(DashBoardActivity.this, "Category does not exist", Toast.LENGTH_LONG).show();
            }
        });


        navigationView.setNavigationItemSelectedListener(item -> {
            int id = item.getItemId();
            Log.d("NavigationView", "Item clicked, ID: " + id);

            if (id == R.id.nav_addCategory) {
                Intent intent = new Intent(DashBoardActivity.this, newEventCategory.class);
                startActivity(intent);
            } else if (id == R.id.nav_logout) {
                logout();
            } else if (id == R.id.nav_categories) {
                Intent intent = new Intent(DashBoardActivity.this, ViewAllCategoriesFragmentPage.class);
                startActivity(intent);
            } else if (id == R.id.nav_events) {
                Intent intent = new Intent(DashBoardActivity.this, ViewAllEventsFragmentPage.class);
                startActivity(intent);
            }

            //after the click, close the drawer
            drawerLayout.closeDrawer(GravityCompat.START);
            return true;
        });


        recyclerView = findViewById(R.id.recyclerView);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);





        HrecyclerView = findViewById(R.id.header_recyclerView);
        HrecyclerView.setLayoutManager(new LinearLayoutManager(this));


        headerAdapter = new FixedTextAdapter();
        HrecyclerView.setAdapter(headerAdapter);



       //Categories Adapter
        recyclerAdapter = new MyRecyclerAdapter();
//        recyclerAdapter.setData(listCategories);
        recyclerView.setAdapter(recyclerAdapter);
        categoriesViewModel = new ViewModelProvider(this).get(CategoriesViewModel.class);
        // subscribe to LiveData of type ArrayList<Student>,
        // any changes detected in the database will be notified to MainActivity
        categoriesViewModel.getAllCategories().observe(this, newData -> {
            //Categories Adapter
            recyclerAdapter = new MyRecyclerAdapter();
//        recyclerAdapter.setData(listCategories);
            recyclerView.setAdapter(recyclerAdapter);
            categoriesViewModel = new ViewModelProvider(this).get(CategoriesViewModel.class);
        });

        View touchPad = findViewById(R.id.touchpad);

        mDetector = new GestureDetectorCompat(this, new GestureListener());

        touchPad.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                mDetector.onTouchEvent(event);
//                表示该 onTouchListener 已经完全处理了触摸事件。不返回 true（如返回 false），那么触摸事件可能会传递给其他视图或上层视图的 onTouchEvent，
//                导致 GestureDetector 可能无法接收到所有事件，从而影响手势识别的准确性。
                return true;
            }
        });

    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        //确保当前 Activity 或 Fragment 处理并“消费”所有传递到该组件的触摸事件。
        return true;
    }
    private class GestureListener extends GestureDetector.SimpleOnGestureListener {


        @Override
        public boolean onDoubleTap(MotionEvent e) {
            String strEventId = generateEventId();
            String strEventName = etEventName.getText().toString();
            int intTicketsAvailable = Integer.parseInt(etTicktsAvailable.getText().toString());
            int TicketsAvailable;
            String strTicketsAvailable = etTicktsAvailable.getText().toString();
            boolean boolTicketsAvailable = etTicktsAvailable.isActivated();
            String strCategoryId = etCategoryId.getText().toString();
            TicketsAvailable = intTicketsAvailable;
            if (isCategoryIdExists(strCategoryId)){
            Events events = new Events(strEventId, strEventName, TicketsAvailable, boolTicketsAvailable,strCategoryId);
            etEventId.setText(strEventId);
            // 更新类别的事件计数
            updateCategoryEventCount(strCategoryId, TicketsAvailable);

            eventsViewModel.insert(events);
            Toast.makeText(getApplicationContext(), "double tap saved successfully", Toast.LENGTH_SHORT).show();}
            else{
                Toast.makeText(getApplicationContext(), "Categories does not exist", Toast.LENGTH_SHORT).show();
            }


            return super.onDoubleTap(e);
        }

        @Override
        public void onLongPress(MotionEvent e) {
            boolean boolTicketsAvailable = etTicktsAvailable.isActivated();
            clearTextView();
            switchIsActive.setChecked(false);
            Toast.makeText(getApplicationContext(), "long press clear field", Toast.LENGTH_SHORT).show();
            super.onLongPress(e);
        }
    }



    private void initializeUIComponents() {
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        switchIsActive = findViewById(R.id.db_IsActive);
        etEventId = findViewById(R.id.db_EventId);
        etEventName = findViewById(R.id.db_EventName);
        etCategoryId = findViewById(R.id.db_CategoryId);
        etTicktsAvailable = findViewById(R.id.db_TicketsAvailable);

    }



    public void loadCategories (){
        //getall use a live data, then observe the change, new arraylist is to change list category
        //to array list category
        //new data means when data changed in view model and what to do next
        categoriesViewModel.getAllCategories().observe(this, newData -> {
            // cast List<Student> to ArrayList<Student>
            recyclerAdapter.setData(new ArrayList<Categories>(newData));  //this part is to notify change in Database to recyclerView
            recyclerAdapter.notifyDataSetChanged();
        });
    }

    private void updateCategoryEventCount(String categoryId, int ticketsAvailable) {
        AtomicBoolean isUpdating = new AtomicBoolean(true);
        categoriesViewModel.getCategoryById(categoryId).observe(this, category -> {
            if (category != null && isUpdating.get()) {
                // 更新事件计数
                int updatedEventCount = category.getEventCount() + ticketsAvailable;
                category.setEventCount(updatedEventCount);

                // 保存更新后的类别对象到数据库
                categoriesViewModel.updateCategory(category);
                //reset to false to finish the loop
                isUpdating.set(false);

            } else {
            }
        });
    }

    private void undoLastSaveEventOperation(String categoryId, int ticketsAvailable) {
        AtomicBoolean isDeleted = new AtomicBoolean(false);


        eventsViewModel.getAllEvents().observe(this, events -> {
            if (!events.isEmpty() && !isDeleted.get()) {

                Events lastEvent = events.get(events.size() - 1);

                    eventsViewModel.delete(lastEvent);

                    isDeleted.set(true);
            } else if (events.isEmpty()) {
                Toast.makeText(this, "No events to delete", Toast.LENGTH_SHORT).show();
            }
        });
    }









    //method to delete all categories
    private void deleteCategories() {
        categoriesViewModel.deleteAll();
    }

    private boolean isCategoryIdExists(String categoryId) {
        final boolean[] exists = {false}; // 使用数组来存储结果
        categoriesViewModel.getAllCategories().observe(this, categories -> {
            for (Categories category : categories) {
                if (category.getId().equals(categoryId)) {
                    exists[0] = true;
                    break;
                }
            }
        });
        return exists[0];
    }







    public void loadEvents (){
        eventsViewModel.getAllEvents().observe(this, newData -> {
            // cast List<Student> to ArrayList<Student>
            eventsAdapter.setData(new ArrayList<Events>(newData));  //this part is to notify change in Database to recyclerView
            eventsAdapter.notifyDataSetChanged();
        });
    }



    private void deleteEvents() {
        eventsViewModel.deleteAll();


        categoriesViewModel.getAllCategories().observe(this, categories -> {
            if (categories != null && !categories.isEmpty()) {
                for (Categories category : categories) {
                    int eventCountToRemove = category.getEventCount();

                    category.setEventCount(0);

                    categoriesViewModel.updateCategory(category);
                }
            }
        });
    }

















    //to inflate the menu on the right side of toolbar and click anction
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // 初始化菜单
        getMenuInflater().inflate(R.menu.options_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.option_deleteAllCategories) {
            // if Restore Student option is selected
            deleteCategories();
        }else if(item.getItemId() == R.id.refresh){
            loadCategories();
            clearTextView();
        }else if(item.getItemId() == R.id.option_deleteAllEvents){
            loadEvents();
            deleteEvents();
        }else if(item.getItemId() == R.id.option_clearEventForm){
            clearEventForm();
        }

        return super.onOptionsItemSelected(item);
    }

    public String generateEventId() {
        Random random = new Random();

        // Generate two random uppercase letters
        char letter1 = (char) ('A' + random.nextInt(26));
        char letter2 = (char) ('A' + random.nextInt(26));

        // Generate four random digits
        int digits = random.nextInt(100000);

        // Format the category ID
        return String.format("E%c%c-%05d", letter1, letter2, digits);
    }
    //to reset all the context on page
    private void clearTextView(){
        etEventName.setText("");
        etCategoryId.setText("");
        etTicktsAvailable.setText("");
    }

    public void logout() {
        Intent intent = new Intent(DashBoardActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }


    private void clearEventForm(){
        initializeUIComponents();
        etEventId.setText("");
        etCategoryId.setText("");
        etEventName.setText("");
        etTicktsAvailable.setText("");
    }


    private boolean isValidEventName(String event) {
        boolean hasValidChars = event.matches("[a-zA-Z]+[a-zA-Z0-9 ]*");
        return hasValidChars;
    }





}